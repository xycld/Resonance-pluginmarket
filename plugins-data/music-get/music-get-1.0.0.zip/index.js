module.exports = { activate() {}, deactivate() {} }
